package org.pugavalera.pndfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrNeuroDispFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
